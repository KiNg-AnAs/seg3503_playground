package tic;

import static org.junit.jupiter.api.Assertions.*;

import java.beans.Transient;

import org.junit.jupiter.api.Test;

class TicTest {
    Tic anas= new tic();
	@Test
	void test1() {
		Tic board = new Tic(3, 2);
		Tic board2 = new Tic(3,3);
		assertEquals(board, board2);
		//testing ability to declare a board
	}

	@Test
	void test2(){
		String[][] empty = {{"_","_","_"},{"_","_","X"}};
		assertEquals(empty,anas.emptyboard());
	}

	@Test
	void test3(){
		String[][] empty = {{"X","_","_"},{"_","_","_"}};
		assertEquals(empty,anas.emptyboard());
	}

	@Test
	void test4(){
		String[][] empty = {{"_","_","_"},{"_","O","_"},{"_","_","_"}};
		assertEquals(empty,anas.emptyboard());
	}

	
	@Test
	void test5(){
		String[][] empty = {{"_","_","_"},{"_","_","_"}};
		assertEquals(7,anas.boardsize(3,3));
	}


}
