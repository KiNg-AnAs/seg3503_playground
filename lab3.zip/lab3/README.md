<br> Coverage before:<br>
 <br> ![image](images/before1.jpeg) <br>
 <br> ![image](images/before2.jpeg) <br>
 <br> ![image](images/ous1.jpeg) <br>
 <br> ![image](images/ous2.jpeg) <br>
 <br> ![image](images/ous3.jpeg) <br>
 <br> ![image](images/before3.jpeg) <br>
 <br> ![image](images/before4.jpeg) <br>
After adding more covergae we reached 100% :
 <br> ![image](images/after%201.jpeg) <br>
 <br> ![image](images/after2.jpeg) <br>
 <br> ![image](images/after3.jpeg) <br>
 <br> ![image](images/after4.jpeg) <br>